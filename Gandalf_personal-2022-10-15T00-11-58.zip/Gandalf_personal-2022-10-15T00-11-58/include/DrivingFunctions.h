#ifndef DRIVINGFUNCTIONS
#define DRIVINGFUNCTIONS

void ArcadeDrive();
void TankDrive();

#endif