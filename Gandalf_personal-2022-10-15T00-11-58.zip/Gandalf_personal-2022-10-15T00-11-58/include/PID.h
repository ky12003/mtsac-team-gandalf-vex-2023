#ifndef PID
#define PID

void auto_straight(int speed);

#endif