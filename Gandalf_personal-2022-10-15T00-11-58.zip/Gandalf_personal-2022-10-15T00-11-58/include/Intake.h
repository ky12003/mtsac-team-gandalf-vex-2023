#ifndef INTAKE
#define INTAKE

void run_intake();
void run_intake_reverse();

#endif