#ifndef LAUNCHER
#define LAUNCHER

void fly_wheel_one_forward();
void fly_wheel_two_forward();

void fly_wheel_one_reverse();
void fly_wheel_two_reverse();

#endif